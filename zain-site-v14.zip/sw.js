// sw.js — ضعه بجانب index.html على نفس الاستضافة
self.addEventListener('install', e => self.skipWaiting());
// v8 — بث مباشر (Agora) لمن لديه 200 متابع+ · ريلز: من شاهد وكم مرة ومن حفظ
self.addEventListener('activate', e => e.waitUntil((async () => {
  await self.clients.claim();
  try { const cs = await self.clients.matchAll({ type: 'window' }); cs.forEach(c => { try { c.navigate(c.url); } catch (x) {} }); } catch (x) {}
})()));

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const d = e.notification.data || {};
  const act = e.action || '';
  const url = d.url || './';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    for (const c of list) {
      if ('focus' in c) {
        if (d.call) c.postMessage({ type: 'call-action', action: act || 'answer' });
        return c.focus();
      }
    }
    if (self.clients.openWindow) return self.clients.openWindow(d.call && act !== 'decline' ? './?answer=1' : url);
  }));
});

// Push حقيقي (FCM) يصل والتطبيق مغلق أو الشاشة مقفلة
self.addEventListener('push', e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { d = { title: 'زين', body: e.data ? e.data.text() : '' }; }
  const p = Object.assign({}, d.data || {}, d.notification || {});
  e.waitUntil((async () => {
    const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    if (list.some(c => c.visibilityState === 'visible')) return;   // التطبيق مفتوح أمامه: لا حاجة للإشعار
    await self.registration.showNotification(p.title || 'زين', {
      body: p.body || '', tag: p.tag || undefined, renotify: true,
      icon: 'icon-v2-192.png', badge: 'icon-v2-192.png', dir: 'rtl', lang: 'ar',
      vibrate: [120, 60, 120], data: { url: p.url || './' }
    });
  })());
});
